ROUTINE MAJOR — mise en ligne (5 minutes)

1. Sur GitHub, crée un nouveau dépôt (ex. "Routine"), public.
2. Dépose À PLAT à la racine tous les fichiers de ce zip (index.html, manifest.json,
   service-worker.js, icon.svg, icon-192.png, icon-512.png). Pas de sous-dossier.
3. Settings > Pages > Deploy from a branch > main / (root). Attends 1-2 minutes.
4. Ouvre https://nawanem812-boop.github.io/<nom-du-dépôt>/ dans Chrome, puis
   menu ⋮ > "Installer l'application" / "Ajouter à l'écran d'accueil".

POURQUOI LE LIEN AVEC PROGRAMME MAJOR MARCHE
Ton site Programme Major et cette appli seront sur le même domaine (nawanem812-boop.github.io).
Le navigateur partage donc leurs données : la routine lit tes cours (J+0/J+1/J+2/J+3/J+7/J+15/J+21/J+30), tes TD,
tes stages et tes QCM en direct, et cocher une révision ou un TD dans la routine le valide dans
Programme Major. Le choix de DA est partagé aussi. Il faut ouvrir les deux depuis le même
navigateur (Chrome). Une appli installée garde en général les mêmes données que Chrome.

SAUVEGARDE (à faire chaque semaine)
Réglages > Exporter : télécharge un fichier .json (et affiche le texte à copier).
- Sur le même domaine que Programme Major, le fichier contient tout (routine + cours + TD + stages
  + QCM). Il peut être réimporté dans Programme Major (Importer) comme dans la routine.
- Importer (routine) : restaure seulement la routine. "Restaurer tout" remet aussi Programme Major.
- Les données sont aussi demandées en stockage "persistant" au navigateur pour limiter les pertes,
  mais seul un export fichier te protège vraiment (cache vidé, nouveau téléphone, désinstallation).

MISE À JOUR : remplace index.html dans le dépôt. Tes données ne sont pas touchées.

NOUVEAUTÉS v2 (d'après ton export Major de promo)
- Rattrapage compressé : un cours resté 3 points de révision en retard ou plus devient UNE tâche « Rattrapage complet » (40 min). La cocher valide les points J+ déjà échus dans Programme Major et ajoute une révision « Rattrapage (Routine Major) » dans le cours.
- Routine recherche & langues (07h15, 30 min, 20 en rattrapage) reprise de ton planning type.
- Journal de stage : le bloc est coché automatiquement s'il existe une entrée à cette date dans Programme Major.
- Sommeil (LIFE-PROJECT-) : si la moyenne des 3 derniers relevés (7 derniers jours) est sous 6 h, le mode Minimal s'active en Auto.
- Suivi > Revue du dimanche : bilan de la semaine (révisions, TD, journal, sommeil, dépenses, retard) avec bouton Copier.
- Importer une sauvegarde sur une autre adresse récupère aussi sommeil et dépenses de LIFE-PROJECT-.
Remplace index.html ET service-worker.js dans le dépôt.

NOTIFICATIONS (v3) + NOUVELLE ICÔNE
- Réglages > Notifications : « Activer les rappels », choix de l'avance (à l'heure, 5, 10, 15, 30 min), sujet ntfy, « Programmer 2 jours », « Tester ».
- Sans ntfy : rappels locaux, seulement si la routine est ouverte ou récemment active (limite des navigateurs).
- Avec ntfy : installe l'appli ntfy, abonne-toi au même sujet (nom long et secret). La routine programme chaque bloc non coché pour aujourd'hui et demain, et se reprogramme à chaque ouverture.
- Remplace TOUS les fichiers du dépôt (icônes comprises). Pour voir la nouvelle icône sur l'écran d'accueil, désinstalle puis réinstalle l'appli (tes données restent dans Chrome).


MISES À JOUR V2 — COPIE DE TRAVAIL
- Suivi des révisions étendu à J+0, J+1, J+2, J+3, J+7, J+15, J+21 et J+30, en conservant les validations des jalons historiques.
- Les semaines qui ne figurent pas dans le calendrier source sont signalées « S2 · à compléter » au lieu d'afficher un calendrier vide ou inventé.
- Ajout d'un éditeur de semaines dans Réglages : date du lundi, libellé et type (site, distance, stage, vacances).
- La restauration complète n'écrase plus les clés inconnues et préserve les applications non concernées.


PRÉCISION V2 — IMPORTS ET CALENDRIER
- « Importer » restaure les données Routine ; « Restaurer tout » restaure les clés reconnues des applications présentes dans la sauvegarde. Les clés inconnues ou absentes du fichier ne sont pas supprimées.
- Le calendrier affiché « S2 · à compléter » n’invente aucun cours. Renseigne les semaines officielles via Réglages > Calendrier IFSI.
- Le cycle de révision utilisé par Routine comporte huit jalons : J0, J1, J2, J3, J7, J15, J21 et J30.
- Le lien « Ouvrir Programme Major » pointe vers le dépôt compagnon Multi-DA-v2. Les versions V2 utilisent les mêmes clés de stockage que les applications d’origine afin de reprendre les données existantes.
Les caches hors-ligne sont également nommés par application : une mise à jour ne supprime pas le cache des deux autres sites.
